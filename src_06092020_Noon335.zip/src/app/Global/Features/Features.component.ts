import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'embryo-Features',
  templateUrl: './Features.component.html',
  styleUrls: ['./Features.component.scss']
})
export class FeaturesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
