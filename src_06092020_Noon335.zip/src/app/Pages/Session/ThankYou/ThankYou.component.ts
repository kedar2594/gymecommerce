import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'embryo-ThankYou',
  templateUrl: './ThankYou.component.html',
  styleUrls: ['./ThankYou.component.scss']
})
export class ThankYouComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
