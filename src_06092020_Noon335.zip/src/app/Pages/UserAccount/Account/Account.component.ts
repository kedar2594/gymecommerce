import { HomeTwoService } from 'src/app/Pages/Home/home-two.service';
import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-Account',
  templateUrl: './Account.component.html',
  styleUrls: ['./Account.component.scss']
})
export class AccountComponent implements OnInit {

  details: any;
  token: any;
  constructor(private homeService: HomeTwoService) {
    // this.details = JSON.parse(localStorage.getItem('userDetails'));
    this.token = localStorage.getItem('token');
    this.viewprofile();
    // console.log('details lofin', this.details);
  }

  ngOnInit() {
  }
  viewprofile() {
    this.homeService.viewprofiledetails().subscribe((data: any) => {
      if (data.isStatus == true) {
        console.log('profiledetailssssss', data.response);
        this.details = data.response;
      } else {
      }
    })
  }
}
