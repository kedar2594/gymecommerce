export const environment = {
  production: true,
 // API_END_POINT:'http://13.233.129.21:8060'
  firebase: {
    apiKey: "AIzaSyC5kr77VEU-FnklR5DBn3bPwmtmpEjYde4",
    authDomain: "embryo-version-2.firebaseapp.com",
    databaseURL: "https://embryo-version-2.firebaseio.com",
    projectId: "embryo-version-2",
    storageBucket: "embryo-version-2.appspot.com",
    messagingSenderId: "73552048992"
  }
};
