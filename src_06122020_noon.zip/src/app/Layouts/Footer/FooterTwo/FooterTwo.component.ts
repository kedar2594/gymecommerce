import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'FooterTwo',
  templateUrl: './FooterTwo.component.html',
  styleUrls: ['./FooterTwo.component.scss']
})
export class FooterTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
