import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'embryo-AppLogo',
  templateUrl: './AppLogo.component.html',
  styleUrls: ['./AppLogo.component.scss']
})
export class AppLogoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
