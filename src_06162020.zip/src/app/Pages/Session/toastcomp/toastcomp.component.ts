import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toastcomp',
  templateUrl: './toastcomp.component.html',
  styleUrls: ['./toastcomp.component.css']
})
export class ToastcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
