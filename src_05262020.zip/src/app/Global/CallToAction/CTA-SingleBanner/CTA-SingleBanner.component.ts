import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'embryo-CTASingleBanner',
  templateUrl: './CTA-SingleBanner.component.html',
  styleUrls: ['./CTA-SingleBanner.component.scss']
})
export class CTASingleBannerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
