import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'embryo-Sales',
  templateUrl: './Sales.component.html',
  styleUrls: ['./Sales.component.scss']
})
export class SalesComponent implements OnInit {

  @Input() advitiseZero: any;

  constructor() {
    console.log('akshatha checking0', this.advitiseZero);
  }

  ngOnInit() {

  }

}
