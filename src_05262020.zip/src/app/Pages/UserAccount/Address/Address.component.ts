import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Address',
  templateUrl: './Address.component.html',
  styleUrls: ['./Address.component.scss']
})
export class AddressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
