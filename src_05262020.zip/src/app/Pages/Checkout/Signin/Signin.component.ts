import { HomeTwoService } from 'src/app/Pages/Home/home-two.service';
import { Component, OnInit } from '@angular/core';
import { EmbryoService } from '../../../Services/Embryo.service';
import { Router, ActivatedRoute, Params } from '@angular/router';


@Component({
  selector: 'app-Signin',
  templateUrl: './Signin.component.html',
  styleUrls: ['./Signin.component.scss']
})
export class SigninComponent implements OnInit {

  orderId: any;
  orderDetails: any;

  constructor(public homeSevice: HomeTwoService, private route: ActivatedRoute,
    private router: Router, public embryoService: EmbryoService) {
    this.route.params.subscribe(params => {

      this.orderId = params['orderId'];
      console.log(this.orderId);
      this.getOrders();
    });
  }

  ngOnInit() {
  }

  getOrders() {
    this.homeSevice.getOrderDetails(this.orderId).subscribe((data: any) => {
      if (data.isStatus == true) {
        this.orderDetails = data.response;
      }
    })
  }

  public toggleRightSidenav() {
    this.embryoService.paymentSidenavOpen = !this.embryoService.paymentSidenavOpen;
  }

  public getCartProducts() {
    let total = 0;
    if (this.embryoService.localStorageCartProducts && this.embryoService.localStorageCartProducts.length > 0) {
      for (let product of this.embryoService.localStorageCartProducts) {
        if (!product.quantity) {
          product.quantity = 1;
        }
        total += (product.sellingPrice * product.quantity);
      }
      total += (this.embryoService.shipping + this.embryoService.tax);
      return total;
    }
    return total;
  }

}
