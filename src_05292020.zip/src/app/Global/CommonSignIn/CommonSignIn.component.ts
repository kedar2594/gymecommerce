import { EmbryoService } from './../../Services/Embryo.service';
import { SessionService } from './../../Pages/Session/session.service';
import { Component, OnInit } from '@angular/core';
import {
  MatSnackBar, MatSnackBarConfig, MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material';


@Component({
  selector: 'embryo-SignIn',
  templateUrl: './CommonSignIn.component.html',
  styleUrls: ['./CommonSignIn.component.scss']
})
export class CommonSignInComponent implements OnInit {

  userName: any;
  password: any;
  durationInSeconds = 2;
  message: string = 'Fields marked with * are mandatory';
  actionButtonLabel: string = 'Login Succussfull';
  actionButtonLabel1: string;
  action: boolean = true;
  autoHide: number = 2000;
  setAutoHide: boolean = true;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  userFullName: any;
  userId: any;
  emailId: any;
  alluserdetail1: any;

  constructor(
    public embryoService: EmbryoService,
    public snackBar: MatSnackBar,
    public sessionService: SessionService) {
    this.alluserdetail1 = JSON.parse(localStorage.getItem("userDetails"));
  }

  ngOnInit() {
  }

  loginUser() {
    if (this.userName == undefined || this.userName == "" || this.userName == null
      || this.password == undefined || this.password == "" || this.password == null) {
      let config = new MatSnackBarConfig();
      config.duration = this.setAutoHide ? this.autoHide : 0;
      this.snackBar.open(this.message, this.action ? this.actionButtonLabel : undefined, config);
    }
    else {
      this.sessionService.loginUser(this.userName, this.password).subscribe((data: any) => {
        if (data.isStatus == true) {
          this.embryoService.navigate('home-two', []);
          let config = new MatSnackBarConfig();
          config.verticalPosition = this.verticalPosition;
          config.horizontalPosition = this.horizontalPosition;
          config.panelClass = ['custom-class1'];
          config.duration = this.setAutoHide ? this.autoHide : 0;
          this.snackBar.open('Welcome to Stayfit ' + this.userName, this.action ? this.actionButtonLabel : undefined, config);
          localStorage.setItem('token', data.token);
          localStorage.setItem('userDetails', JSON.stringify(data.response));
          // this.embryoService.userLoginLocalStoreage(data.response);
          this.userId = data.response.userId;
          this.userName = data.response.userName;
          this.userFullName = data.response.userFullName;
          this.emailId = data.response.emailId;
          let sessionUser = {

            emailId: this.emailId,
            userId: this.userId,
            userName: this.userName,
            userFullName: this.userFullName

          }

        } else {
          let config = new MatSnackBarConfig();
          config.verticalPosition = this.verticalPosition;
          config.horizontalPosition = this.horizontalPosition;
          config.panelClass = ['custom-class1'];
          config.duration = this.setAutoHide ? this.autoHide : 0;
          this.snackBar.open(data.response, this.action ? this.actionButtonLabel1 : undefined, config);
        }
      })
    }
  }

}
