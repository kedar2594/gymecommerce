import { OrdersComponent } from './../Orders/Orders.component';
import { HomeTwoService } from 'src/app/Pages/Home/home-two.service';
import { Component, OnInit } from '@angular/core';
import { EmbryoService } from '../../../Services/Embryo.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-Signin',
  templateUrl: './Signin.component.html',
  styleUrls: ['./Signin.component.scss']
})



export class SigninComponent implements OnInit {

  orderId: any;
  orderDetails: any = [];
  cartProducts: any;
  popupResponse: any;
  constructor(public dialog: MatDialog, public homeSevice: HomeTwoService, private route: ActivatedRoute,
    private router: Router, public embryoService: EmbryoService) {
    this.route.params.subscribe(params => {

      this.orderId = params['orderId'];
      console.log(this.orderId);
      this.getOrders();
    });
  }

  ngOnInit() {
  }

  getOrders() {
    this.homeSevice.getOrderDetails(this.orderId).subscribe((data: any) => {
      if (data.isStatus == true) {
        this.orderDetails = data.response;
        console.log(this.orderDetails);

      }
    })
  }

  public toggleRightSidenav() {
    this.embryoService.paymentSidenavOpen = !this.embryoService.paymentSidenavOpen;
  }

  openDialog() {
    const dialogRef = this.dialog.open(OrdersComponent, {
      height: '500px', width: '500px',
      data: this.orderDetails
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');

    });

  }


  public getCartProducts() {
    let total = 0;
    if (this.embryoService.localStorageCartProducts && this.embryoService.localStorageCartProducts.length > 0) {
      for (let product of this.embryoService.localStorageCartProducts) {
        if (!product.quantity) {
          product.quantity = 1;
        }
        total += (product.sellingPrice * product.quantity);
      }
      total += (this.embryoService.shipping + this.embryoService.tax);
      return total;
    }
    return total;
  }
  public calculateTotalPrice() {
    let subtotal = 0;
    if (this.embryoService.localStorageCartProducts && this.embryoService.localStorageCartProducts.length > 0) {
      for (let product of this.embryoService.localStorageCartProducts) {
        subtotal += (product.sellingPrice * product.quantity);
      }
    }
    return subtotal;
  }

  public removeProduct(value) {
    let message = "Are you sure you want to delete this product?";
    this.embryoService.confirmationPopup(message).
      subscribe(res => { this.popupResponse = res },
        err => console.log(err),
        () => this.getPopupResponse(this.popupResponse, value)
      );
  }

  public getPopupResponse(response, value) {
    if (response) {
      this.embryoService.removeLocalCartProduct(value);
      this.embryoService.paymentSidenavOpen = false;
    }
  }

  public calculateProductSinglePrice(product: any, value: any) {
    let price = 0;
    product.quantity = value;
    price = product.sellingPrice * value;
    return price;
  }

  public getTotalPrice() {
    let total = 0;
    if (this.embryoService.localStorageCartProducts && this.embryoService.localStorageCartProducts.length > 0) {
      for (let product of this.embryoService.localStorageCartProducts) {
        total += (product.sellingPrice * product.quantity);
      }
      total += (this.embryoService.shipping + this.embryoService.tax);
    }
    return total;
  }

  public closeSlider() {

    this.embryoService.paymentSidenavOpen = !this.embryoService.paymentSidenavOpen;

  }
}
