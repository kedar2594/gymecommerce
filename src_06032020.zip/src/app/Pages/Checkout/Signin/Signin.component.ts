import { OrdersComponent } from './../Orders/Orders.component';
import { HomeTwoService } from 'src/app/Pages/Home/home-two.service';
import { Component, OnInit } from '@angular/core';
import { EmbryoService } from '../../../Services/Embryo.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-Signin',
  templateUrl: './Signin.component.html',
  styleUrls: ['./Signin.component.scss']
})



export class SigninComponent implements OnInit {

  orderId: any;
  orderDetails: any = [];
  cartProducts: any;
  popupResponse: any;

  // cartProducts: any = [{ 'id': 0 }];

  constructor(public dialog: MatDialog, public homeSevice: HomeTwoService, private route: ActivatedRoute,
    private router: Router, public embryoService: EmbryoService) {
    // this.cartProducts.length = 0;

    localStorage.removeItem('cart_item');
    this.route.params.subscribe(params => {
      this.orderId = params['orderId'];
      console.log(this.orderId);
      this.getOrders();
    });
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
    // window.location.reload();
    let win = (window as any);
    var urlParams = [];
    window.location.search.replace("?", "").split("&").forEach(function (e, i) {
      var p = e.split("=");
      urlParams[p[0]] = p[1];
    });

    // We have all the params now -> you can access it by name
    console.log(urlParams["loaded"]);

    if (urlParams["loaded"]) { } else {

      let win = (window as any);
      win.location.search = '?loaded=1';
      //win.location.reload('?loaded=1');
    }
  }

  ngOnInit() {


  }

  getOrders() {
    this.homeSevice.getOrderDetails(this.orderId).subscribe((data: any) => {
      if (data.isStatus == true) {
        this.orderDetails = data.response;
        console.log(this.orderDetails);

      }
    })
  }

  public toggleRightSidenav() {
    this.embryoService.paymentSidenavOpen = !this.embryoService.paymentSidenavOpen;
  }

  openDialog() {
    const dialogRef = this.dialog.open(OrdersComponent, {

      data: this.orderDetails,

      width: '550px',
      maxHeight: 'calc(100vh - 90px)',
      height: 'auto'
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  public getCartProducts() {
    let total = 0;
    if (this.embryoService.localStorageCartProducts && this.embryoService.localStorageCartProducts.length > 0) {
      for (let product of this.embryoService.localStorageCartProducts) {
        let price = 0;
        if (product.discountPercentage > 0) {

          total += ((product.sellingPrice) - (product.sellingPrice * (product.discountPercentage / 100))) * product.quantity;
          // return subtotal;
        } else {

          total += (product.sellingPrice * product.quantity);
          // return subtotal;
        }
      }
      return total;
    }
    return total;
  }
  public calculateTotalPrice() {
    let subtotal = 0;
    if (this.embryoService.localStorageCartProducts && this.embryoService.localStorageCartProducts.length > 0) {
      for (let product of this.embryoService.localStorageCartProducts) {
        subtotal += (product.sellingPrice * product.quantity);
      }
    }
    return subtotal;
  }

  public removeProduct(value) {
    let message = "Are you sure you want to delete this product?";
    this.embryoService.confirmationPopup(message).
      subscribe(res => { this.popupResponse = res },
        err => console.log(err),
        () => this.getPopupResponse(this.popupResponse, value)
      );
  }

  public getPopupResponse(response, value) {
    if (response) {
      this.embryoService.removeLocalCartProduct(value);
      this.embryoService.paymentSidenavOpen = false;
    }
  }

  public calculateProductSinglePrice(product: any, value: any) {
    let price = 0;
    product.quantity = value;
    price = product.sellingPrice * value;
    return price;
  }

  public getTotalPrice() {
    let total = 0;
    if (this.embryoService.localStorageCartProducts && this.embryoService.localStorageCartProducts.length > 0) {
      for (let product of this.embryoService.localStorageCartProducts) {
        total += (product.sellingPrice * product.quantity);
      }
      total += (this.embryoService.shipping + this.embryoService.tax);
    }
    return total;
  }

  public closeSlider() {

    this.embryoService.paymentSidenavOpen = !this.embryoService.paymentSidenavOpen;

  }

  continuePayment() {
    this.router.navigate(['/checkout/payment', { 'orderId': this.orderId }])
  }

}
