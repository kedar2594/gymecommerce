import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'embryo-NotFound',
  templateUrl: './NotFound.component.html',
  styleUrls: ['./NotFound.component.scss']
})
export class NotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
