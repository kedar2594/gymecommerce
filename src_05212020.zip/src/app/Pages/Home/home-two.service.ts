import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class HomeTwoService {

  private host = 'http://13.233.129.21:8060'
  private url: string = '';

  constructor(private http: HttpClient) { }

  viewproducts() {
    this.url = this.host + '/Product/ViewMultipleProducts';
    return this.http.get(this.url);
  }
  viewProdSpecification(productId) {
    this.url = this.host + '/Product/ViewProductById?productId=' + productId;
    return this.http.get(this.url);
  }

  // viewproducts() {
  //   this.url = this.host + '/Product/ViewMultipleProducts';
  //   return this.http.get(this.url);
  //   }

  viewtodayDealsOfTheDay() {
    this.url = this.host + '/DealsOfTheDay/GetTodaysDealsOfTheDay';
    return this.http.get(this.url);
  }

  viewTopProducts() {
    this.url = this.host + '/Product/ViewTopProducts';
    return this.http.get(this.url);
  }

  //Topbar menue Items

  viewTopbarMenues() {
    this.url = this.host + '/Menubar/ViewAllForPortal';
    return this.http.get(this.url);
  }

  //quick Access

  viewQuickAccess() {
    this.url = this.host + '/QuickLink/ViewMultipleQuickLink';
    return this.http.get(this.url);
  }

  viewAdvitise() {
    this.url = this.host + '/Advertisement/ViewMultipleAdvertisement';
    return this.http.get(this.url);
  }


}
