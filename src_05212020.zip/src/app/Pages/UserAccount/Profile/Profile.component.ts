import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Profile',
  templateUrl: './Profile.component.html',
  styleUrls: ['./Profile.component.scss']
})
export class ProfileComponent implements OnInit {

  details: any;
  constructor() {
    this.details = JSON.parse(localStorage.getItem('userDetails'));
    console.log('details lofin', this.details);
  }

  ngOnInit() {
  }

}
