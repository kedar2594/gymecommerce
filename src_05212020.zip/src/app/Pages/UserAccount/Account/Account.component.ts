import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Account',
  templateUrl: './Account.component.html',
  styleUrls: ['./Account.component.scss']
})
export class AccountComponent implements OnInit {

  details: any;
  constructor() {
    this.details = JSON.parse(localStorage.getItem('userDetails'));
    console.log('details lofin', this.details);
  }

  ngOnInit() {
  }

}
