import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'embryo-Sales1',
  templateUrl: './sales1.component.html',
  styleUrls: ['./sales1.component.scss']
})
export class Sales1Component implements OnInit {
  @Input() advitiseOne: any;
  constructor() { }

  ngOnInit() {
    console.log('akshatha checking1', this.advitiseOne);
  }

}
